<?php
error_reporting(E_ALL ^ E_NOTICE);
// Modulo desarrollado por Mercedes Weffer para SofOS C.A 
include ("dbkey.php");
if (isset($_POST)){
	$vendedor=$_POST['vendedor']; 
	$FechadeSolicitud=$_POST['FechadeSolicitud'];
	$tipo=$_POST['tipo']; 
	$Ejecutivo=$_POST['Ejecutivo'];
	$Actividad=$_POST['Actividad'];
	$TipoCliente=$_POST['TipoCliente'];
    $pais=$_POST['pais'];
	$cliente=$_POST['cliente'];
	$nombree=$_POST['nombree'];
	$actividadeconomica=$_POST['actividadeconomica'];
	$sector=$_POST['sector'];
	$telefono=$_POST['telefono'];
	$direccion=$_POST['direccion'];
	$grupo=$_POST['grupo'];
	$paise=$_POST['paise'];
	$sel=pg_query ("SELECT * FROM registro");
	$nrosolicitud=pg_num_rows($sel)+1;
	$codhx=dechex($nrosolicitud);
	$insertar=pg_query ("INSERT INTO registro(vendedor, fsolicitud, tipo, epreventas, apreventas, tcliente, 
            cliente, pais, codhx, nrosolicitud)
    VALUES ('$vendedor','$FechadeSolicitud','$tipo','$Ejecutivo', '$Actividad', '$TipoCliente', 
            '$cliente','$pais', '$codhx','$nrosolicitud')");
	$insertar2=pg_query ("INSERT INTO empresa(
            nombree, actividade, sectorindustrial, telefono, direccion, grupo, 
            paise) 
	 VALUES ('$nombree','$actividade','$sector','$telefono', '$direccion', '$grupo', 
            '$pais')");
} 
header ("Location: index.php?pag=2&res=1&codhx=$codhx");
?> 