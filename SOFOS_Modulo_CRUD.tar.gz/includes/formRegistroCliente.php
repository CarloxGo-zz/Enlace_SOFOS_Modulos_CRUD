<!DOCTYPE HTML5>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Form Validation</title>
	<link rel="stylesheet" href="css/fv.css" type="text/css" />
	<!--[if IE]
	<style>
		.item .tooltip .content{ display:none; opacity:1; }
		.item .tooltip:hover .content{ display:block; }
	</style>
	<![endif]-->
</head>
<body>
<div id='wrap'>
  <div class='options'>
    <label>
      <input name="checkbox" type='checkbox' id='vfields' />
      Orientación Vertical </label>
    <label>
      <input name="checkbox2" type='checkbox' id='alerts' />
      Quitar Alertas </label>
  </div>
  <img src="images/regemp.png" width="45%">
  <section class='form'>
    <form action="procesarCliente.php" method="post" novalidate>
      <fieldset>
        <div class="item"><label>
        <h2>Datos de la Empresa</h2>
        </label>
        </div>
        <div class="item">
          <label> <span>Nombre Empresa</span>
            <input data-validate-length-range="3" name="cliente" placeholder="" required type="text" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Validar si la Empresa est&aacute;</p>
                <p>o no registrada</p>
            </div>
          </div>
        </div>
        
        <div class="item">
          <label> <span>Tel&eacute;fono</span>
            <input type="tel" class='tel' name="telefono" required='required' data-validate-length-range="8,20">
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Importante: Como complemento al n&uacute;mero se puede incluir el s&iacute;gno '+' , un gui&oacute;n '-' o un espacio en blanco ' '</p>
            </div>
          </div>
        </div>
        
        <div class="item">
          <label> <span>Actividad Econ&oacute;mica</span>
          <input data-validate-length-range="4" name="actividade" placeholder="" required type="text" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
            <p>Actividad General o Raz&oacute;n Social</p></div>
          </div>
        </div>
        
        <div class="item">
          <label> <span>Sector Industrial</span>
          <input data-validate-length-range="4" name="sector" placeholder="" type="text" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
            <p>Solo en caso de aplicar</p></div>
          </div>
        </div>
        
          <div class="item">
          <label> <span>Grupo</span>
          <input data-validate-length-range="4" name="grupo" placeholder="" required type="text" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
            <p>Grupo al que Pertenece</p></div>
          </div>
        </div>
       
        <div class="item">
          <label> <span>P&aacute;gina Web</span>
            <input name="pagina" placeholder="http://www.website.com" required type="url" />
          </label>
        </div>
       
        <div class="item">
          <label> <span>Direcci&oacute;n</span>
            <textarea name="direccion" rows="3" required="required"></textarea>
          </label><div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
            <p>Incluir: Ciudad, Pa&iacute;s y C&oacute;digo Postal</p></div>
          </div>
        </div>
      </fieldset>
      <div align="right"> <button id='send' type='submit'>Registrar Cliente</button></div>
    </form>
  </section>
</div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://dropthebit.com/demos/validator/multifield.js"></script>
    <script src="js/validator.js"></script>
	<script>
		// initialize the validator function
		validator.message['date'] = 'not a real date';
		
		// validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
		$('form')
			.on('blur', 'input[required], input.optional, select.required', validator.checkField)
			.on('change', 'select.required', validator.checkField);
			
		$('.multi.required')
			.on('keyup', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			}).on('blur', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			});
		
		// bind the validation to the form submit event
		//$('#send').click('submit');//.prop('disabled', true);
		
		$('form').submit(function(e){
			e.preventDefault();
			var submit = true;
			// evaluate the form using generic validaing
			if( !validator.checkAll( $(this) ) ){
				submit = false;
			}

			if( submit )
				this.submit();
			return false;
		});
		
		/* FOR DEMO ONLY */
		$('#vfields').change(function(){
			$('form').toggleClass('mode2');
		}).prop('checked',false);
		
		$('#alerts').change(function(){
			validator.defaults.alerts = (this.checked) ? false : true;
			if( this.checked )
				$('form .alert').remove();
		}).prop('checked',false);
	</script>
</body>
</html>