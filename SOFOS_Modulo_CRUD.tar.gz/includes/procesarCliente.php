<?php
$cliente=$_POST['cliente'];
$actividade=$_POST['actividade'];
$sector=$_POST['sector'];
$direccion=$_POST['direccion'];
$grupo=$_POST['grupo'];
$pagina=$_POST['pagina'];
$telefono=$_POST['telefono'];

include('cnx.php');

$registrar=mysqli_query($link, "INSERT INTO `solicitudes`.`prospecto` (`cliente`, `actividade`, `sector`, `direccion`, `grupo`, `pagina`, `telefono`) 
	VALUES ('$cliente', '$actividade', '$sector', '$direccion', '$grupo', '$pagina', '$telefono')") 
	or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());

header("location: resultado.php?clntreg=1");
?>