<?php
$ejecutivo=$_POST['ejecutivo'];
$apoyo=$_POST['apoyo'];
$nrosolicitud=$_POST['nrosolicitud'];
include('cnx.php');

$upd=mysqli_query($link, "UPDATE `solicitudes`.`registro` SET `ejecutivo` = '$ejecutivo', `apoyo` = '$apoyo' WHERE `registro`.`nrosolicitud` = '$nrosolicitud'") 
or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());

header("location: resultado.php?ejereg=1");
?>