<?php
$nrosolicitud=$_GET['nrosolicitud'];
include('cnx.php');
$buscar=mysqli_query($link, "SELECT * FROM `solicitudes`.`registro` WHERE nrosolicitud='$nrosolicitud' ORDER BY `fsolicitud` ASC");
  while($row=mysqli_fetch_array($buscar)){
    
$contenido='<!DOCTYPE HTML5>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Reporte individual en Excel</title>
    </head>
    <body>
      <table>
        <tr><td>Reporte Individual de Preventa</td><td>&nbsp;</td></tr>
        <tr><td>N° de Solicitud </td><td>'.$row['nrosolicitud'].'</td></tr>
        <tr><td>Vendedor</td><td>'.$row['vendedor'].'</td></tr>
        <tr><td>Tipo</td><td>'.$row['tipo'].'</td></tr>
        <tr><td>Fecha Solicitud</td><td>'.$row['fsolicitud'].'</td></tr>
        <tr><td>Fecha Actividad</td><td>'.$row['factividad'].'</td></tr>
        <tr><td>Fecha Asignaci&oacute;n</td><td>'.$row['fasignacion'].'</td></tr>
        <tr><td>Fecha Preventa</td><td>'.$row['fpreventa'].'</td></tr>
        <tr><td>Ejecutivo Preventa</td></td>'.$row['ejecutivo'].'</td></tr>
        <tr><td>Actividad  Preventa</td><td>'.$row['actividad'].'</td></tr>
        <tr><td>Cliente</td><td>'.$row['cliente'].'</td></tr>
        <tr><td>Pa&iacute;s</td></td>'.$row['pais'].'</td></tr>
        <tr><td>Ejecutivo Preventa</td><td>'.$row['ejecutivo'].'</td></tr>
        <tr><td>Actividad  Preventa</td><td>'.$row['actividad'].'</td></tr>
        <tr><td>Cliente</td><td>'.$row['cliente'].'</td></tr>
        <tr><td>Estatus</td><td>'.$row['status'].'</td></tr>
        <tr><td>>Descripción</td><td>'.$row['desc'].'</td></tr>
        </table>
    </body>
    </html>';

    echo $contenido;
$f=str_replace(':','',str_replace(' ','',date("Y-m-d H:i:s")));
echo $archivo='archivos/'.$f.'.xls';
$fp=fopen($archivo,"x");
fwrite($fp,$contenido);
fclose($fp);
header("Location: $archivo");
?>
    </body>
    </html>
<?php } ?>