<?php
error_reporting(E_ALL ^ E_NOTICE);
if($_SERVER['HTTP_REFERER']==""){
  session_start();
  session_destroy();
  header("location: ../seguridad/session.php");
}
include("../seguridad/security_system.php");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Form Validation</title>
	<link rel="stylesheet" href="css/fv.css" type="text/css" />
	<!--[if IE]
	<style>
		.item .tooltip .content{ display:none; opacity:1; }
		.item .tooltip:hover .content{ display:block; }
	</style>
	<![endif]-->
</head>
<body>
<div id='wrap'>
  <div class='options'>
    <label>
      <input name="checkbox" type='checkbox' id='vfields' />
      Orientación Vertical </label>
    <label>
      <input name="checkbox2" type='checkbox' id='alerts' />
      Quitar Alertas </label>
  </div>
  <img src="images/solicitud.png" width="50%">
  <section class='form'>
    <form action="procesarPreventa.php" method="post" novalidate>
      <fieldset>
     	<div class="item"><label><h2>Datos de la Preventa</h2></label></div>
        <div class="item">
          <label><span>Vendedor</span>
            <input name="vendedor" required="required" list="vendedores" value="<?php echo $_SESSION['nombre'];?>">
            <datalist id="vendedores">
            <?php 
              include('cnx.php');
              $buscar1  = mysqli_query($link, "SELECT * FROM `empleados`");
              while ($row1=mysqli_fetch_array($buscar1)) {
                echo '<option value="'.$row1['nombre'].' '.$row1['apellido'].'">'.$row1['cod_empleado'].'</option>';
              } 
            ?>
            </datalist>
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Nombre del Vendedor debe tener</p>
            </div>
          </div>
        </div>

		<div class="item">
          <label> <span>Tipo</span></label>
          <table width="200" border="1">
                  <tr>
                    <td>Presencial</td>
                    <td><input id="rad" type="radio" value="Presencial" name="tipo" checked="checked"></td>
                    <td>Remoto </td>
                    <td> <input id="rad" type="radio" value="Remoto" name="tipo"></td>
                  </tr>
          </table>
		</div>
        		
        <div class="item">
          <label> <span>Fecha Solicitud</span>
            <input class='date' type="text" disabled="disabled" value="<?php  echo date("d").'/'.date("m").'/'.date("Y"); ?>">
            <input type="hidden" value="<?php echo date("Y").'-'.date("m").'-'.date("d"); ?>" name="fsolicitud">
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Fecha de Solicitud de la Preventa se carga automaticamente</p>
            </div>
          </div>
        </div>
        
        <div class="item">
          <label> <span>Fecha Actividad</span>
            <input class='date' type="date" name="factividad" disabled placeholder="DD/MM/AAAA" >
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Fecha de la Actividad</p>
                <p>Normalmente es la misma que la Fecha de Solicitud</p>
            </div>
          </div>
        </div>

        <div class="item">
          <label> <span>Ejecutivo Preventa</span>
          <input name="ejecutivo" required="required" list="ejecutivos">
          <datalist id="ejecutivos">
            <?php
                $buscar2 = mysqli_query($link, "SELECT * FROM `empleados`");
                while ($row2=mysqli_fetch_array($buscar2)) {
                  echo '<option value="'.$row2['nombre'].' '.$row2['apellido'].'">'.$row2['cod_empleado'].'</option>';
                } 
              ?>          
          </datalist>
            <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Ejecutivo encargado de la Preventa</p>
				<p>Puede ser asignado luego</p>
            </div>
          </div>
        </div>
        
        <div class="item">
          
          <label> <span>Actividad  Preventa:</span>
          <input data-validate-length-range="2" name="actividad" placeholder="Actividad" required="required" type="text" value="<?php echo $_GET['actividad'];?>"/></label>

      </div>
        <div class="item">
          <label> <span>Cliente</span></label>
          <select class="required" name="cliente">
              <option value="SAAS">SAAS</option>
              <option value="Farmatodo">Farmatodo</option>
              <option value="Nestl&eacute;">Nestl&eacute;</option>
              <option value="Unilever">Unilever</option>
              <option value="Makro">Makro</option>
			  <?php
			  $Ssql=mysqli_fetch_array($link, "SELECT cliente FROM prospecto");	
			  while($fila=mysqli_fetch_array($Ssql)){
			  	echo '<option value="'.$fila['cliente'].'">'.$fila['cliente'].'</option>';
			  }	
			  ?>
            </select>
          <div class='tooltip help'> <span>?</span>  
            <div class='content'> <b></b>
                <p>Empresa que hace la Preventa</p>
            </div>
          </div>
        </div>
        <div class="item">
          <label><span>&nbsp;</span></label><a href="formRegistroCliente.php">¿Cliente nuevo? Click aqu&iacute;</a>        
       	</div>
        <div class="item">
          <label> <span>Pa&iacute;s: </span>
            <select class="required" name="pais" required="required">
              <option value="Venezuela">Venezuela</option>
              <option value="Colombia">Colombia</option>
              <option value="Ecuador">Ecuador</option>
              <option value="Argentina">Argentina</option>
              <option value="Otros">Otros</option>
            </select>
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Pa&iacute;s donde se ejecuta la Preventa</p>
            </div>
          </div>
      </div>
      <div class="item">
          <label> <span>Descripci&oacute;n </span>
          <textarea data-validate-length-range="2" rows="5" name="desc" placeholder="Descripcion de Actividad de Pre-Venta" type="text" /><?php echo $_GET['desc'];?></textarea></label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Descripci&oacute;n de la actividad de Pre-Ventas </p>
        <p>Ser Especifico</p>
            </div>
          </div>
        </div>
      </fieldset>
      <div align="right"> <button id='send' type='submit'>Registrar</button></div>
    </form>
  </section>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://dropthebit.com/demos/validator/multifield.js"></script>
    <script src="js/validator.js"></script>
	<script>
		// initialize the validator function
		validator.message['date'] = 'not a real date';
		
		// validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
		$('form')
			.on('blur', 'input[required], input.optional, select.required', validator.checkField)
			.on('change', 'select.required', validator.checkField);
			
		$('.multi.required')
			.on('keyup', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			}).on('blur', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			});
		
		// bind the validation to the form submit event
		//$('#send').click('submit');//.prop('disabled', true);
		
		$('form').submit(function(e){
			e.preventDefault();
			var submit = true;
			// evaluate the form using generic validaing
			if( !validator.checkAll( $(this) ) ){
				submit = false;
			}

			if( submit )
				this.submit();
			return false;
		});
		
		/* FOR DEMO ONLY */
		$('#vfields').change(function(){
			$('form').toggleClass('mode2');
		}).prop('checked',false);
		
		$('#alerts').change(function(){
			validator.defaults.alerts = (this.checked) ? false : true;
			if( this.checked )
				$('form .alert').remove();
		}).prop('checked',false);
	</script>
  <?php
  error_reporting(E_ALL ^ E_NOTICE);
  if ($_GET['error']==1){
    echo "<script> alert('Fecha de Actividad no puede ser previa a la fecha de registro de la Preventa');</script>";
  }
  if ($_GET['error']==2){
    echo "<script> alert('El nombre del Vendedor es incorrecto, por favor verifique');</script>";
  }
    if ($_GET['error']==3){
    echo "<script> alert('El nombre del Ejecutivo es incorrecto, por favor verifique');</script>";
  }
  ?>
</body>
</html>