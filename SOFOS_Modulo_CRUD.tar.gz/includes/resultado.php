
<html>
<head>
<meta charset="utf-8">
    <meta charset="UTF-8">
    <title>Asignar</title>
	<link rel="stylesheet" href="css/fv.css" type="text/css" />
	<!--[if IE]
	<style>
		.item .tooltip .content{ display:none; opacity:1; }
		.item .tooltip:hover .content{ display:block; }
	</style>
	<![endif]-->
<body>
<div id='wrap'>
  <div class='options'>
    <label>
      <input name="checkbox" type='checkbox' id='vfields' />
      Orientación Vertical </label>
    <label>
      <input name="checkbox2" type='checkbox' id='alerts' />
      Quitar Alertas </label>
  </div>

<section class='form'>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</section>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://dropthebit.com/demos/validator/multifield.js"></script>
    <script src="js/validator.js"></script>
	<script>
		// initialize the validator function
		validator.message['date'] = 'not a real date';
		
		// validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
		$('form')
			.on('blur', 'input[required], input.optional, select.required', validator.checkField)
			.on('change', 'select.required', validator.checkField);
			
		$('.multi.required')
			.on('keyup', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			}).on('blur', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			});
		
		// bind the validation to the form submit event
		//$('#send').click('submit');//.prop('disabled', true);
		
		$('form').submit(function(e){
			e.preventDefault();
			var submit = true;
			// evaluate the form using generic validaing
			if( !validator.checkAll( $(this) ) ){
				submit = false;
			}

			if( submit )
				this.submit();
			return false;
		});
		
		/* FOR DEMO ONLY */
		$('#vfields').change(function(){
			$('form').toggleClass('mode2');
		}).prop('checked',false);
		
		$('#alerts').change(function(){
			validator.defaults.alerts = (this.checked) ? false : true;
			if( this.checked )
				$('form .alert').remove();
		}).prop('checked',false);
	</script>
<?php
error_reporting(E_ALL ^ E_NOTICE);
if ($_GET['error']==1){
	echo "<script> alert('N° de Solicitud no resgistrado, por favor verificar');</script>";
}

if ($_GET['ejereg']==1) {
	echo "<script> alert('Ejecutivo asignado satisfactoriamente a la Preventa seleccionada');</script>";
}

if ($_GET['prvenreg']==1) {
	echo "<script> alert('Preventa registrada satisfactoriamente. Nº de Solicitud ".$_GET[nrosol]."');</script>";
}

if ($_GET['clntreg']==1) {
	echo "<script> alert('Cliente satisfactoriamente registrado en nuestra Base de Datos.');</script>";
}

if ($_GET['fasigreg']==1) {
	echo "<script> alert('Fecha de Asignación de la Preventa satisfactoriamente registrada.');</script>";
}

if ($_GET['fconreg']==1) {
	echo "<script> alert('Fecha de Confirmación de la Preventa satisfactoriamente registrada.');</script>";
}

if ($_GET['statreg']==1) {
	echo "<script> alert('Estatus satisfactoriamente modificado.');</script>";
}


?>
</body>
</head>
</html>