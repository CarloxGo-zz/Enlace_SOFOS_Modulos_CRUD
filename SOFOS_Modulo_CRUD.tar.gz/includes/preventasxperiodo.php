<html>
<head>
<meta charset="utf-8">
    <meta charset="UTF-8">
    <title>Asignar</title>
	<link rel="stylesheet" href="css/fv.css" type="text/css" />
	
	<!--[if IE]
	<style>
		.item .tooltip .content{ display:none; opacity:1; }
		.item .tooltip:hover .content{ display:block; }
	</style>
	<![endif]-->
<body>
<div id='wrap'>
  <div class='options'>
    <label>
      <input name="checkbox" type='checkbox' id='vfields' />
      Orientación Vertical </label>
    <label>
      <input name="checkbox2" type='checkbox' id='alerts' />
      Quitar Alertas </label>
  </div>

<section class='form'>
<form action="listadoxfecha.php" method="post">
      <fieldset>
     	<div class="item"><label><h2>Buscar Solicitud</h2></label></div>
        <div class="item">
          <label> <span>Fecha de Inicio</span>
            <input class='date' type="date" name="fechainicio" placeholder="DD/MM/AAAA" required="required" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Fecha de inicio del per&iacute;odo deseado</p>
                 <p>Debe ser igual o menor que la "Fecha de Finalización"</p>
            </div>
          </div>
        </div>
         <div class="item">
          <label> <span>Fecha Fin</span>
             <input class='date' type="date" name="fechafin" placeholder="DD/MM/AAAA" required="required" />
          </label>
          <div class='tooltip help'> <span>?</span>
            <div class='content'> <b></b>
                <p>Fecha de finalizaci&oacute;n del per&iacute;odo deseado</p>
                <p>Debe ser igual o mayor que la "Fecha de Inicio"</p>
            </div>
          </div>
        </div>
		<div class="item">
		 <div align="right"> <button id='send' type='submit'>Buscar Solicitud</button></div></div>
	</fieldset>
</form>
</section>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://dropthebit.com/demos/validator/multifield.js"></script>
    <script src="js/validator.js"></script>
	<script>
		// initialize the validator function
		validator.message['date'] = 'not a real date';
		
		// validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
		$('form')
			.on('blur', 'input[required], input.optional, select.required', validator.checkField)
			.on('change', 'select.required', validator.checkField);
			
		$('.multi.required')
			.on('keyup', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			}).on('blur', 'input', function(){ 
				validator.checkField.apply( $(this).siblings().last()[0] );
			});
		
		// bind the validation to the form submit event
		//$('#send').click('submit');//.prop('disabled', true);
		
		$('form').submit(function(e){
			e.preventDefault();
			var submit = true;
			// Se evalúa el formulario usando validación genérica
			if( !validator.checkAll( $(this) ) ){
				submit = false;
			}

			if( submit )
				this.submit();
			return false;
		});
		
		/* FOR DEMO ONLY */
		$('#vfields').change(function(){
			$('form').toggleClass('mode2');
		}).prop('checked',false);
		
		$('#alerts').change(function(){
			validator.defaults.alerts = (this.checked) ? false : true;
			if( this.checked )
				$('form .alert').remove();
		}).prop('checked',false);
	</script>
<?php
error_reporting(E_ALL ^ E_NOTICE);
switch($_GET['error']){
	case 1:
		echo "<script>alert('`Fecha Fin` no puede ser menor  que `Fecha Inicio`, por favor verificar');</script>";
	break;
	case 2:
		echo "<script>alert('No hay Preventas en el período seleccionado');</script>";
	break;
	case 3:
		echo "<script>alert('Las fechas seleccionadas no pueden ser mayores que la fecha del día de hoy');</script>";
	break;
}
?>
</body>
</head>
</html>