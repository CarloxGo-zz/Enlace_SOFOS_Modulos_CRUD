<?php
$nrosolicitud=$_GET['nrosolicitud'];
include('cnx.php');
$buscar=mysqli_query($link, "SELECT * FROM `solicitudes`.`registro` WHERE nrosolicitud='$nrosolicitud' ORDER BY `fsolicitud` ASC");
if(mysqli_num_rows($buscar)==0){
  header("location: resultado.php?error=1");
}else{
  while($row=mysqli_fetch_array($buscar)){
    ?>
    <!DOCTYPE HTML5>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Total Form Validation</title>
      <link rel="stylesheet" href="css/fv.css" type="text/css" />
      <!--[if IE]
      <style>
        .item .tooltip .content{ display:none; opacity:1; }
        .item .tooltip:hover .content{ display:block; }
      </style>
      <![endif]-->
    </head>
    <body>
    <div id='wrap'>
      <div class='options'>
        <label>
          <input name="checkbox" type='checkbox' id='vfields' />
          Orientación Vertical </label>
        <label>
          <input name="checkbox2" type='checkbox' id='alerts' />
          Quitar Alertas </label>
      </div>
      <img src="images/solicitud.png" width="50%">
      <section class='form'>
      <form action="regfconfirma.php" method="post">
          <fieldset>
          <div class="item"><label>
          <h2>Datos de la Preventa - Fecha de Asignación </h2>
          </label></div>
        <div class="item">
              <label> <span>N° de Solicitud </span>
                <input name="nrosolicitud" type="hidden" value="<?php echo $row['nrosolicitud'];?>"/>
                <input  type="text" disabled="disabled" value="<?php echo $row['nrosolicitud'];?>"/>
              </label>
            </div>
            <div class="item">
               <label> <span>Vendedor</span>
                <input name="vendedor" type="text" disabled="disabled" value="<?php echo $row['vendedor'];?>"/>
              </label>
            </div>

        <div class="item">
              <label> <span>Tipo</span></label>
              <input name="tipo" type="text" disabled="disabled" value="<?php echo $row['tipo'];?>"/>
        </div>
        <div class="item">
              <label> <span>Fecha Solicitud</span>
                <input class='date' type="date" name="fsolicitud" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['fsolicitud'];?>" >
              </label>
          </div>
        <div class="item">
              <label> <span>Fecha Actividad</span>
                <input class='date' type="date" name="factividad" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['factividad'];?>">
              </label>
            </div>
        <div class="item">
              <label> <span>Fecha Asignaci&oacute;n</span>
                <input class='date' type="date" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['fasignacion'];?>">
                <input type="hidden" name="fasignacion" placeholder="DD/MM/AAAA" value="<?php 
               echo $row['fasignacion'];
                //echo $fasignacion;
                ?>">
              </label>
            </div>
        <div class="item">
              <label> <span>Fecha Preventa</span>
                <input class='date' type="date" name="fpreventa" placeholder="DD/MM/AAAA" data-validate-length-range="10" required="required" >
              </label>
              <div class='tooltip help'> <span>?</span>
                <div class='content'> <b></b>
                    <p>Fecha de Confirmaci&oacute;n de la Preventa</p>
                </div>
              </div>
            </div>
        
        <div class="item">
              <label> <span>Ejecutivo Preventa</span>
                <input name="ejecutivo" placeholder="Ejecutivo" type="text" value="<?php echo $row['ejecutivo'];?>" disabled="disabled"/>
              </label>
            </div> 
        <div class="item">
              <label> <span>Actividad  Preventa:</span>
             <input name="actividad" type="text" disabled="disabled" value="<?php echo $row['actividad'];?>"/></label>
          </div>
            <div class="item">
              <label> <span>Cliente</span>
               <input name="cliente" type="text" disabled="disabled" value="<?php echo $row['cliente'];?>"/></label>
            </div>
          <div class="item">
              <label> <span>Pa&iacute;s: </span>
                <input name="pais" type="text" disabled="disabled" value="<?php echo $row['pais'];?>"/></label>
          </div>
          </fieldset>
          <div align="right"> <button id='send' type='submit'>Asignar Fecha</button>
          </div>
      </form>
    </section>
    </div>
    </body>
    </html>
      <?php
  }
}

if (isset($_GET['errorr'])){
  switch($_GET['errorr']){
      case 0:
        echo "<script>alert('Registro de fechas procesado Satisfactoriamente');</script>";
      break;
      case 1:
        echo "<script>alert('`Fecha de Asignación` no puede ser menor  que `Fecha de Confirmaci&oacute;n`, por favor verificar');</script>";
      break;
      case 2:
        echo "<script>alert('Las fechas seleccionadas no pueden ser mayores que la fecha del día de hoy');</script>";
      break;
      case 3:
        echo "<script>alert('La fecha seleccionadas no pueden ser mayores que la fecha del día de hoy');</script>";
      break;
  }
}
?>