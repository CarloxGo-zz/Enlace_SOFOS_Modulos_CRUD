<?php
$fasignacion=$_POST['fasignacion'];
$factividad=$_POST['factividad'];
$nrosolicitud=$_POST['nrosolicitud'];
if($fasignacion < $factividad){
	header("location: fechaasignacion.php?errorr=1&nrosolicitud=$nrosolicitud");
}else{
	if($fasignacion > date("Y-m-j") || $factividad > date("Y-m-j")){
		header("location: fechaasignacion.php?errorr=2&nrosolicitud=$nrosolicitud");
	}else{
		include('cnx.php');
		$upd=mysqli_query($link, "UPDATE `solicitudes`.`registro` SET `fasignacion` = '$fasignacion', `factividad` = '$factividad' WHERE `registro`.`nrosolicitud` = '$nrosolicitud'") 
		or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());
		header("location: fechaasignacion.php?errorr=0&nrosolicitud=$nrosolicitud");
	}
}

?>