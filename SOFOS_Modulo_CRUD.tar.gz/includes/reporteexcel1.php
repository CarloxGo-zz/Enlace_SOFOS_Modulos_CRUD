<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="css/tabla.css">
</head>
<body>
<?php
$fechainicio=$_REQUEST['fechainicio'];
$fechafin=$_REQUEST['fechafin'];

include('cnx.php');

$contenido.='<table><thead><tr><th>Nº Solicitud</th><th>F.Solicitud</th><th>Cliente</th><th>Pa&iacute;s</th><th>Estatus</th><th>Vendedor</th>
			</tr></thead><tbody>';

				$Ssql=mysqli_query($link, "SELECT * FROM `registro` WHERE `fsolicitud` BETWEEN '$fechainicio' AND '$fechafin' ORDER BY `fsolicitud` ASC") or die("Error al leer entre las dos fechas");
				while($row=mysqli_fetch_array($Ssql)){
					$contenido.='<tr><td align="center"><div style="font-size:20px;">'.$row['nrosolicitud'].'</a></div></td><td>'.$row['fsolicitud'].'</td><td>'.$row['cliente'].'</td><td>'.$row['pais'].'</td><td>'.$row['status'].'</td><td>'.$row['vendedor'].'</td></tr>';
				}
$contenido.='</tbody></table></body></html>';

$f=str_replace(':','',str_replace(' ','',date("Y-m-d H:i:s")));
echo $archivo='archivos/'.$f.'.xls';
$fp=fopen($archivo,"x");
fwrite($fp,$contenido);
fclose($fp);
header("Location: $archivo");
?>
</div>
</body>
</html>