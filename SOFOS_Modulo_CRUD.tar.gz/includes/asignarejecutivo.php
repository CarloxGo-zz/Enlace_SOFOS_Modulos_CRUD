<?php
$nrosolicitud=$_GET['nrosolicitud'];
include('cnx.php');
$buscar=mysqli_query($link, "SELECT * FROM `solicitudes`.`registro` WHERE nrosolicitud='$nrosolicitud'");
$buscar2=mysqli_query($link, "SELECT * FROM `empleado`");
$buscar3=mysqli_query($link, "SELECT * FROM `empleado`");
if(mysqli_num_rows($buscar)==0){
  header("location: resultado.php?error=1");
}else{
  while($row=mysqli_fetch_array($buscar)){
    ?>
    <!DOCTYPE HTML5>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Total Form Validation</title>
    	<link rel="stylesheet" href="css/fv.css" type="text/css" />
    	<!--[if IE]
    	<style>
    		.item .tooltip .content{ display:none; opacity:1; }
    		.item .tooltip:hover .content{ display:block; }
    	</style>
    	<![endif]-->
    </head>
    <body>
    <div id='wrap'>
      <div class='options'>
        <label>
          <input name="checkbox" type='checkbox' id='vfields' />
          Orientación Vertical </label>
        <label>
          <input name="checkbox2" type='checkbox' id='alerts' />
          Quitar Alertas </label>
      </div>
      <img src="images/solicitud.png" width="50%">
      <section class='form'>
    	<form action="regeje.php" method="post">
          <fieldset>
         	<div class="item"><label><h2>Datos de la Preventa - Asignar Ejecutivo</h2></label></div>
    		<div class="item">
              <label> <span>N° de Solicitud </span>
                <input name="nrosolicitud" type="hidden" value="<?php echo $row['nrosolicitud'];?>"/>
                <input  type="text" disabled="disabled" value="<?php echo $row['nrosolicitud'];?>"/>
              </label>
            </div>
            <div class="item">
              <label> <span>Vendedor</span>
                <input name="vendedor" type="text" disabled="disabled" value="<?php echo $row['vendedor'];?>"/>
              </label>
            </div>

    		<div class="item">
              <label> <span>Tipo</span>
              <input name="tipo" type="text" disabled="disabled" value="<?php echo $row['tipo'];?>"/></label>
    		</div>
    	  <div class="item">
              <label> <span>Fecha Solicitud</span>
                <input class='date' type="date" name="fsolicitud" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['fsolicitud'];?>" >
              </label>
            </div>
    		<div class="item">
              <label> <span>Fecha Actividad</span>
                <input class='date' type="date" name="factividad" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['factividad'];?>">
              </label>
            </div>
    		<div class="item">
              <label> <span>Fecha Preventa</span>
                <input class='date' type="date" name="fpreventa" placeholder="DD/MM/AAAA" disabled="disabled" value="<?php echo $row['fpreventa'];?>">
              </label>
            </div>
            <div class="item">
              <label> <span>Ejecutivo Preventa</span>
              <select name="ejecutivo">
              <?php 
                while ($row2=mysqli_fetch_array($buscar2)) {
                  echo '<option value="'.$row2[nombre].' '.$row2[apellido].'">'.$row2[nombre].' '.$row2[apellido].'</option>';
                } 
              ?>
            </select>

             </label>
              <div class='tooltip help'> <span>?</span>
                <div class='content'> <b></b>
                    <p>Ejecutivo encargado de la Preventa</p>
                </div>
              </div>
            </div>
            
            <div class="item">
              <label> <span>Ejecutivo Apoyo</span>
            <select name="apoyo">
              <?php 
                while ($row3=mysqli_fetch_array($buscar3)) {
                  echo '<option value="'.$row3[nombre].' '.$row3[apellido].'">'.$row3[nombre].' '.$row3[apellido].'</option>';
                }
              ?>
              </select>

             </label>
              <div class='tooltip help'> <span>?</span>
                <div class='content'> <b></b>
                    <p>Ejecutivo de Apoyo de la Preventa</p>
                </div>
              </div>
            </div>

          <div class="item">
              
              <label><span>Actividad Preventa:</span>
              <input name="actividad" type="text"disabled="disabled" value="<?php echo $row['actividad'];?>"/></label>
          </div>
            <div class="item">
              <label><span>Cliente</span>
              <input name="cliente" type="text" disabled="disabled" value="<?php echo $row['cliente'];?>"/></label>
            </div>
          <div class="item">
              <label><span>Pa&iacute;s: </span>
                <input name="pais" type="text" disabled="disabled" value="<?php echo $row['pais'];?>"/></label>
            </div>
          </fieldset>
          <div align="right"><button id='send' type='submit'>Asignar Ejecutivo</button>
          </div>
    	</form>
    </section>
    </div>
    </body>
    </html>
  <?php
  }
}
?>