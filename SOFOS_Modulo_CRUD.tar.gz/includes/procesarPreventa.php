<?php
$fsolicitud=$_POST['fsolicitud'];
$factividad=$fsolicitud;
$vendedor=$_POST['vendedor'];
$actividad=$_POST['actividad'];
$ejecutivo=$_POST['ejecutivo'];
$pais=$_POST['pais'];
$cliente=$_POST['cliente'];
$tipo=$_POST['tipo'];
$desc=$_POST['desc'];

include('cnx.php');

$vnd = explode(" ", $vendedor);
$eje = explode(" ", $ejecutivo);

$nombre_vendedor = $vnd[0];
$apellido_vendedor = $vnd[1];

$nombre_ejecutivo = $eje[0];
$apellido_ejecutivo = $eje[1];

$validar_vendedor = mysqli_query($link, "SELECT * FROM `solicitudes`.`empleados` WHERE `nombre` = '$nombre_vendedor' && `apellido` = '$apellido_vendedor'") 
or die ("Error al buscar el trabajador registrado. Error: ".mysqli_error()); 

$validar_ejecutivo = mysqli_query($link, "SELECT * FROM `solicitudes`.`empleados` WHERE `nombre` = '$nombre_ejecutivo' && `apellido` = '$apellido_ejecutivo'") 
or die ("Error al buscar el trabajador registrado. Error: ".mysqli_error()); 

if(mysqli_num_rows($validar_vendedor)==0){
	header("location: formRegistroPreventa.php?error=2&actividad=$actividad&desc=$desc");
	end();
}

if(mysqli_num_rows($validar_ejecutivo)==0){
	header("location: formRegistroPreventa.php?error=3&actividad=$actividad&desc=$desc");
	end();
}

$registrar=mysqli_query($link, "INSERT INTO `solicitudes`.`registro` (`nrosolicitud`, `fsolicitud`, `factividad`, `vendedor`, `actividad`, `ejecutivo`, `pais`, `cliente`, `tipo`, `status`, `desc` ) 
	VALUES (NULL, '$fsolicitud', '$factividad', '$vendedor', '$actividad', '$ejecutivo', '$pais', '$cliente', '$tipo', 'Iniciado', '$desc')") 
or die ("Error al intentar actualizar el registro. Error: ".mysqli_error()); 


$lastreg=mysqli_query($link, "SELECT MAX(nrosolicitud) AS id FROM registro") or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());
while ($row3=mysqli_fetch_array($lastreg)){
	$nrosol=trim($row3[0]);
}

/*
OTRA FORMA DE HACERLOS
$lastreg=mysqli_query($link, "SELECT nrosolicitud FROM `solicitudes`.`registro` ORDER BY nrosolicitud DESC LIMIT 1,1") or die ("Error al intentar leer los registros. Error: ".mysqli_error());
while ($row=mysqli_fetch_array($lastreg)){
	echo 'Numero de preventa: '.$nrosol=trim($row[0]);
}
*/

header("location: resultado.php?prvenreg=1&nrosol=$nrosol");
?>