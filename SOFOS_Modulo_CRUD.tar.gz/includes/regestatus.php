<?php
$status=$_POST['status'];
$nrosolicitud=$_POST['nrosolicitud'];
include('cnx.php');

$upd=mysqli_query($link, "UPDATE `solicitudes`.`registro` SET `status` = '$status' WHERE `registro`.`nrosolicitud` = '$nrosolicitud'") 
or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());

header("location: resultado.php?statreg=1");
?>