<?php
echo $fpreventa=$_POST['fpreventa'];
$fasignacion==$_POST['fasignacion'];
$nrosolicitud=$_POST['nrosolicitud'];

if($fpreventa > date("Y-m-j") || $fpreventa < $fasignacion){
		header("location: fechaconfirmacion.php?errorr=3&nrosolicitud=$nrosolicitud");
}else{
	include('cnx.php');
	$upd=mysqli_query($link, "UPDATE `solicitudes`.`registro` SET `fpreventa` = '$fpreventa'  WHERE `registro`.`nrosolicitud` = '$nrosolicitud'") 
	or die ("Error al intentar actualizar el registro. Error: ".mysqli_error());
	header("location: resultado.php?fconreg=1");
}
?>