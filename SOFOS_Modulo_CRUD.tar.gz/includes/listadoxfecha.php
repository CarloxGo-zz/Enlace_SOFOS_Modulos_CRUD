<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="css/tabla.css">
</head>
<body>
<?php
$fechainicio=$_REQUEST['fechainicio'];
$fechafin=$_REQUEST['fechafin'];

include('cnx.php');

if($fechainicio > $fechafin){
  header("location: preventasxperiodo.php?error=1");
}else{
	if($fechafin > date("Y-m-j") || $fechafin > date("Y-m-j")){
		header("location: preventasxperiodo.php?error=3");
	}else{	
		?>
		
		<div class="datagrid">
			<table>
					<thead>
						<tr>
							<th>Nº Solicitud</th><th>F.Solicitud</th><th>Cliente</th><th>Pa&iacute;s</th><th>Estatus</th><th>Vendedor</th>
						</tr>
					</thead>
					<tfoot>
						<tr><td colspan="6">
							<div id="paging">
								<ul>
									<li><a href="reporteexcel1.php?fechainicio=<?php echo $_REQUEST['fechainicio'];?>&fechafin=<?php echo $_REQUEST['fechafin'];?>"><span>Exportar a Excel</span></a></li>
								</ul>
							</div>
						</tr>
					</tfoot>
					<tbody>
					<?php
						$Ssql=mysqli_query($link, "SELECT * FROM `registro` WHERE `fsolicitud` BETWEEN '$fechainicio' AND '$fechafin'  ORDER BY `fsolicitud` ASC") or die("Error al leer entre las dos fechas");
		
						if(mysqli_num_rows($Ssql)){$numero=0;
							while($row=mysqli_fetch_array($Ssql)){
								
								if ($numero%2==0){
								   echo '<tr class="alt"><td align="center"><div style="font-size:20px;"><a href="modificarestado.php?nrosolicitud='.$row['nrosolicitud'].'">'.$row['nrosolicitud'].'</a></div></td><td>'.$row['fsolicitud'].'</td><td>'.$row['cliente'].'</td><td>'.$row['pais'].'</td><td>'.$row['status'].'</td><td>'.$row['vendedor'].'</td></tr>';
								}else{
								   echo '<tr><td align="center"><div style="font-size:20px;"><a href="modificarestado.php?nrosolicitud='.$row['nrosolicitud'].'">'.$row['nrosolicitud'].'</a></div></td><td>'.$row['fsolicitud'].'</td><td>'.$row['cliente'].'</td><td>'.$row['pais'].'</td><td>'.$row['status'].'</td><td>'.$row['vendedor'].'</td></tr>';
								}
								$numero++;
							}
						}else{
							header("location: preventasxperiodo.php?error=2");
						}
						?>	
					</tbody>
				</table>
		</div>
		<?php
	}
}
?>
</body>
</html>