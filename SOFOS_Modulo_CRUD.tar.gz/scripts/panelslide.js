//92five.net

$(document).ready(function(){
 
$(".btn-slide").click(function(){
$("#slide-panel").slideToggle("slow");
});
 
}); 