<?php
error_reporting(E_ALL ^ E_NOTICE);
ini_set("session.use_only_cookies","1");
ini_set("session.use_trans_sid","0");
session_start();
session_set_cookie_params(0, "/", $_SERVER["HTTP_HOST"], 0);
if ($_SESSION["autentificado"] != "SI"){
    header("Location: /sistema/seguridad/session.php");
    session_name("usuario");
   	exit();
}else{
    $fechaGuardada = $_SESSION["ultimoacceso"];
    $ahora = date("Y-n-j H:i:s");
    $tiempo_transcurrido = (strtotime($ahora)-strtotime($fechaGuardada));
    // Configuraci�n del tiempo que va a durar la sesi�n antes de vencerse
    if($tiempo_transcurrido >= 300){
    	session_destroy();
    	header("Location: /sistema/seguridad/session.php");
   	}else{      
    $_SESSION["ultimoacceso"] = $ahora;
	}
}
?>