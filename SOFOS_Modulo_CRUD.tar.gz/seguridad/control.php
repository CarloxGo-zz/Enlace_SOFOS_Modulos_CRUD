<?php
// Conexion el servidor
include ("../includes/cnx.php");

$user=htmlentities(trim($_POST["user"]));

$pass=htmlentities(trim($_POST["pass"]));

$result = mysqli_query($link, "SELECT * FROM empleados WHERE login='$user' && pass='$pass'") or die ("Error al buscar usuario y password");

if(mysqli_num_rows($result)!=0)
	{
	//usuario y contrase�a v�lidos
    //defino una sesion y guardo datos
    session_start();
	session_name("$user");
    $_SESSION["autentificado"]= "SI";
	$_SESSION["ultimoacceso"]= date("Y-n-j H:i:s");
	
	//eliminar espacios en la cadena
	$usermod=str_replace( " ", "_", $user );
	//------------------------------
	setcookie("$usermod", $user, time()+120,"/","");
	
	while($row1=mysqli_fetch_array($result)){
		$cod_empleado=$row1['cod_empleado'];
		$_SESSION['nombre']= $row1['nombre'].' '.$row1['apellido'];
		$_SESSION['user']= $row1['login'];
		$buscar_nivel = mysqli_query($link, "SELECT * FROM niveles WHERE cod_empleado='$cod_empleado'")
		 or die ("Error al buscar nivel del usuario");
		while($row2=mysqli_fetch_array($buscar_nivel)){
			$_SESSION['nivel']=$row2['nivel'];
		}
	}
	header ("Location: ../index.php");
}else {
	//Sino ex�ste le mando otra vez a la portada
	header("Location: session.php?errorusuario=si&user=$user");
}

//mysql_close($dbh);
?>