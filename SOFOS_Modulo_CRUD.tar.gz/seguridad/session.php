<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sofosgroup S3. Bienvenidos</title>

 <meta charset="UTF-8">
    <title>Autentificaci&oacute;n SofosGroup S3</title>
  <link rel="stylesheet" href="../css/fv.css" type="text/css" />
  <!--[if IE]
  <style>
    .item .tooltip .content{ display:none; opacity:1; }
    .item .tooltip:hover .content{ display:block; }
  </style>
  <![endif]-->


</head>
<body oncontextmenu="return false">
  <div id='wrap' align="center">
    <form action="control.php" method="POST">
      <div id="content">
        <h1 align="center" style="color: #078C00">Autentificaci&oacute;n Sofosgroup S3 </h1>
        <p align="center"><table width="268" border="0" align="center" cellpadding="2" cellspacing="2" style="background:#EDEDED; font-weight: 900;">
    <tr>
    	<?php
      error_reporting (E_ALL ^ E_NOTICE);
    	if ($_GET["errorusuario"]=="si"){
      	?>
      	<td colspan="2" align="center" style="background:#E70000; color: #FCFFFE;"><span >Datos incorrectos</span>
      	<?php
    	}else{
      	?>
      	<td colspan="2" align="center" style="background:#DCD8D8; color: #01945B;"><span >Introduce tu clave de acceso</span>
      <?php
    	}
    	?>
    	</td>
    </tr>
    <tr>
    <td width="119" align="right">Usuario:</td>
    <td width="135"><input type="text" name="user" size="15" maxlength="20" value="<?php echo $login ?>"></td></tr>
    <tr>
    <td align="right">Clave:</td>
    <td><?php echo '<input type="password" name="pass" size="15" maxlength="20"></td>'; ?></tr>
    <tr>
    <td colspan="2" align="center"><input type="Submit" value="Accesar" style="background:#FFB400"></td>
    </tr>
    </table>
        </p>
      </div>
    </form>
    <?php
    if ($_GET['error']==1){
      echo '<script> alert("Usuario y/o constrase�a err�neo, favor revisar");</script>';
    }
    ?>
</div>
  </body>
</html>
