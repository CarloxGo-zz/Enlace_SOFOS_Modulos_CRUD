<?php
session_start();
session_destroy();
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Sofosgroup S3. Hasta Luego</title>

 <meta charset="UTF-8">
    <title>Total Form Validation</title>
  <link rel="stylesheet" href="../css/fv.css" type="text/css" />
  <!--[if IE]
  <style>
    .item .tooltip .content{ display:none; opacity:1; }
    .item .tooltip:hover .content{ display:block; }
  </style>
  <![endif]-->

</head>

<body oncontextmenu="return false">
<div id='wrap'>
  <div id="content"><div class="feature"><div align="center">
  	  <h3>&nbsp;</h3>
<h1 class="Estilo77"><u>ATENCION</u></h1>
<h1 class="Estilo78">Usted est&aacute; ha salido de una sesi&oacute;n autorizada, </h1>
<h1 class="Estilo78">para accesar nuevamente </h1>
<h1 class="Estilo79"><span class="Estilo80">click sobre este enlace</span> <span class="Estilo80"><a href="session.php"><strong><u>Inicio de Sesi&oacute;n</u></strong></a></span></h1>
<p class="Estilo79">&nbsp;</p>
<p class="Estilo1"> (para mayor informaci&oacute;n comun&iacute;quese con el Administrador)</p>
</div>
	</div>
</div>
</div>
<!--end pagecell1-->
<br />
</body>
</html>