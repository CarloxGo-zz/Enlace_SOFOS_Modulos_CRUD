<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once('class.ezpdf.php');
$pdf =& new Cezpdf('A3', 'landscape');
$pdf->selectFont('../fonts/php_Helvetica-Oblique.afm');
$pdf->ezSetCmMargins(1,1,1.5,1.5);

include('cnx.php');

$fechainicio = $_REQUEST['fechainicio'];
$fechafin = $_REQUEST['fechafin'];
$status = $_REQUEST['status'];

$resEmp = mysqli_query($link, "SELECT * FROM `registro` WHERE  `status` = '$status' AND `fsolicitud` BETWEEN '$fechainicio' AND '$fechafin' ORDER BY `fsolicitud` ASC") or die("Error al leer entre las dos fechas");
$totEmp = mysqli_num_rows($resEmp);

$ixx = 0;
while($datatmp = mysqli_fetch_assoc($resEmp)) { 
	$ixx = $ixx+1;
	$data[] = array_merge($datatmp, array('num'=>$ixx));
}
$titles = array(
				'nrosolicitud'=>'<b>Num.Sol.</b>',
				'fsolicitud'=>'<b>Fecha de Solicitud</b>',
				'factividad'=>'<b>Fecha de Actividad</b>','fpreventa'=>'<b>Fecha Preventa</b>','fasignacion'=>'<b>Fecha Asignaci�n</b>',
				'actividad'=>'<b>Vendedor</b>',
				'ejecutivo'=>'<b>Ejecutivo</b>',
				
				'pais'=>'<b>Pa�s</b>',
				'cliente'=>'<b>Prospecto</b>',
				'tipo'=>'<b>Tipo</b>',
				
				'status'=>'<b>Estatus</b>',
				
				
				'desc'=>'<b>Descripci�n</b>'
			);
$options = array(
				'shadeCol'=>array(0.5,0.5,0.9),
				'xOrientation'=>'center',
				'width'=>1100
			);//'apoyo '=>'<b>Apoyo</b>','asignar'=>'<b>Asignar</b>',
$txttit2 = "Reporte por Estatus</b>";

$txttit.= "Per�odo $fechainicio al $fechafin \n";

$image1 = imagecreatefromjpeg("logo.jpg");
$image2 = imagecreatefromjpeg("SAP-Logo.jpg");

$pdf->addImage($image1,30,735,200);
$pdf->addImage($image2,980,740,160);

$pdf->ezText($txttit2, 24);
$pdf->ezText($txttit, 18);
$pdf->ezTable($data, $titles, '', $options);
$pdf->ezText(".", 14);
$pdf->ezText("<b>Sistema S3. Sofosgroup.</b>\n<b>Fecha:</b> ".date("d/m/Y"), 14);
$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n", 14);
$pdf->ezStream();
?>