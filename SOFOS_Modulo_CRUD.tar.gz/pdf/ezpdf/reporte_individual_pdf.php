<?php
error_reporting(E_ALL ^ E_NOTICE);
include('cnx.php');
include('class.ezpdf.php');
$nrosolicitud=$_GET['nrosolicitud'];
$pdf =& new Cezpdf('LETTER');
$pdf->selectFont('fonts/Courier.afm');
$datacreator = array (
					'Title'=>'Reporte Individual por Num. de Preventa',
					'Author'=>'SofosGroup',
					'Subject'=>'Nº de Preventa'.$nrosolicitud,
					'Creator'=>'Departamento de Sistemas',
					'Producer'=>'http://www.sofosgroup.com'
					);
$pdf->addInfo($datacreator);
$buscar=mysqli_query($link, "SELECT * FROM `solicitudes`.`registro` WHERE nrosolicitud='$nrosolicitud'");
while ($row=mysqli_fetch_array($buscar)) {
	$data[] = array('num'=>"<b>Num. de Solicitud</b>", 'detalle'=>$row['nrosolicitud']);
	$data[] = array('num'=>"<b>Fecha de Solicitud</b>", 'detalle'=>$row['fsolicitud']);
	$data[] = array('num'=>"<b>Fecha de Actividad</b>", 'detalle'=>$row['factividad']);
	$data[] = array('num'=>"<b>Fecha Preventa</b>", 'detalle'=>$row['fpreventa']);
	$data[] = array('num'=>"<b>Fecha Asignacion</b>", 'detalle'=>$row['fasignacion']);
	$data[] = array('num'=>"<b>Vendedor</b>", 'detalle'=>$row['actividad']);
	$data[] = array('num'=>"<b>Ejecutivo</b>", 'detalle'=>$row['ejecutivo']);
	$data[] = array('num'=>"<b>Pais</b>", 'detalle'=>$row['pais']);
	$data[] = array('num'=>"<b>Prospecto</b>", 'detalle'=>$row['cliente']);
	$data[] = array('num'=>"<b>Tipo</b>", 'detalle'=>$row['tipo']);
	$data[] = array('num'=>"<b>Estatus</b>", 'detalle'=>$row['status']);
	$data[] = array('num'=>"<b>Descripcion</b>", 'detalle'=>$row['desc']);
}
$titles = array('num'=>'<b>Item</b>', 'detalle'=>'<b>________________Detalle________________</b>');

$image1 = imagecreatefromjpeg("logo.jpg");
$image2 = imagecreatefromjpeg("SAP-Logo.jpg");

$pdf->addImage($image1,30,690,200);
$pdf->addImage($image2,430,700,140);

$pdf->ezText("<b>Reporte Preventa</b>",25);
$pdf->ezText("Detalle por Item\n",16);
$pdf->ezTable($data,$titles,'',$options );
$pdf->ezText("\n\n\n",10);
$pdf->ezText("<b>Sistema S3. Sofosgroup.</b>\n<b>Fecha:</b> ".date("d/m/Y"), 14);
$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n", 14);
$pdf->ezStream();
?>

