<?php
	$user="root";
	$pass="";
	$server="localhost";
	$bd="solicitudes";
	$link= mysqli_connect($server, $user, $pass, $bd) or die("Error al conectar a MySQL. Error: ".mysqli_error());
?>